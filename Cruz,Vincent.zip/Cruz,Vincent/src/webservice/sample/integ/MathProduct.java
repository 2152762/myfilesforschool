package webservice.sample.integ;

import javax.jws.WebMethod;
import javax.jws.WebService;

//provides the server the correct methods to use
@WebService
public interface MathProduct {
    @WebMethod
    public boolean isOdd(int num);
    @WebMethod
    public int roundOffNearestTens(int num);
    @WebMethod
    public int largestFactor(int num1, int num2);   
}
