/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package webservice.sample.integ;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;


public class WebClient {
    public static void main(String[] args) throws MalformedURLException {
//       provides the url to be accessed in xml form
        URL url = new URL("http://127.0.0.1:5000/MathProduct?wsdl");
//       creates an object that represents a qualified name as defined in the xml specifications
        QName qname = new QName("http://integ.sample.webservice/", "MathFunctionsService");
        Service service = Service.create(url, qname);
        MathProduct stub = service.getPort(MathProduct.class);
        
        System.out.println("Is 2019 odd? " + stub.isOdd(2019));
        System.out.println("GCD of 91 and 21: " + stub.largestFactor(91, 21));
        System.out.println("1234 rounded-off(?) to the nearest tens: " + stub.roundOffNearestTens(1234));
    }
    
}
